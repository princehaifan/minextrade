#!/usr/bin/env python3
"""Size a position from the stop distance. Never size from a lot you like.

Examples
--------
FX:      position_size.py --equity 10000 --risk-pct 1 --entry 1.0824 --stop 1.0789 \
                          --contract-size 100000 --target 1.0902
Perp:    position_size.py --equity 10000 --risk-pct 1 --entry 0.13448 --stop 0.1485 \
                          --contract-size 10 --lot-step 1 --min-lot 1 \
                          --leverage 10 --maintenance 0.03 --side short
"""
import argparse
import math


def fmt(x, places=2):
    return f"{x:,.{places}f}"


def main():
    p = argparse.ArgumentParser(description="Position sizer (risk-based).")
    p.add_argument("--equity", type=float, required=True)
    p.add_argument("--risk-pct", type=float, required=True)
    p.add_argument("--entry", type=float, required=True)
    p.add_argument("--stop", type=float, required=True)
    p.add_argument("--contract-size", type=float, default=1.0,
                   help="units per lot: FX 100000, gold 100, index 1, perp quanto multiplier")
    p.add_argument("--lot-step", type=float, default=0.01)
    p.add_argument("--min-lot", type=float, default=0.01)
    p.add_argument("--target", type=float, default=None)
    p.add_argument("--leverage", type=float, default=None)
    p.add_argument("--maintenance", type=float, default=0.005,
                   help="maintenance margin rate, e.g. 0.03 for 3%%")
    p.add_argument("--side", choices=["long", "short"], default=None)
    a = p.parse_args()

    risk_money = a.equity * a.risk_pct / 100.0
    dist = abs(a.entry - a.stop)
    if dist <= 0:
        raise SystemExit("Stop equals entry: no risk defined, no trade.")

    units = risk_money / dist
    lots_raw = units / a.contract_size
    lots = math.floor(lots_raw / a.lot_step + 1e-9) * a.lot_step
    lots = round(lots, 8)

    print("POSITION SIZE")
    print(f"  equity            {fmt(a.equity)}")
    print(f"  risk              {a.risk_pct:g}%  =  {fmt(risk_money)}")
    print(f"  stop distance     {dist:.6g}  ({(dist / a.entry) * 100:.2f}% of price)")
    print(f"  units required    {fmt(units, 4)}")
    print(f"  lots (raw)        {fmt(lots_raw, 4)}")

    if lots < a.min_lot:
        print(f"  lots (rounded)    {lots:g}  ->  NO TRADE: below the {a.min_lot:g} minimum.")
        print("  The stop is too wide for this account at this risk. Skip it.")
        return

    actual_units = lots * a.contract_size
    actual_risk = actual_units * dist
    print(f"  lots (rounded)    {lots:g}")
    print(f"  actual risk       {fmt(actual_risk)}  =  {actual_risk / a.equity * 100:.2f}% of equity")

    if a.target:
        r = abs(a.target - a.entry) / dist
        print(f"  R to target       {r:.2f}R")
        if r < 2:
            print("  WARNING: below the 2R minimum — factor 6 fails.")

    if a.leverage:
        side = a.side or ("long" if a.stop < a.entry else "short")
        liq_dist = 1.0 / a.leverage - a.maintenance
        liq = a.entry * (1 - liq_dist) if side == "long" else a.entry * (1 + liq_dist)
        reachable = (a.stop > liq) if side == "long" else (a.stop < liq)
        print("LIQUIDATION")
        print(f"  {side} at {a.leverage:g}x, maintenance {a.maintenance * 100:.2f}%")
        print(f"  liquidation distance  {liq_dist * 100:.2f}%  ->  price {liq:.6g}")
        print(f"  stop {a.stop:.6g} reachable?  {'YES' if reachable else 'NO — the position dies first'}")
        if not reachable:
            max_lev = 1.0 / (dist / a.entry + a.maintenance)
            print(f"  maximum leverage with this stop: {max_lev:.1f}x — use a third of it")


if __name__ == "__main__":
    main()
