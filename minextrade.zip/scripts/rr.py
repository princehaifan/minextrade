#!/usr/bin/env python3
"""R multiple, break-even win rate, expectancy and liquidation check.

Examples
--------
rr.py --entry 0.13448 --stop 0.15616 --target 0.10837 --side short
rr.py --entry 0.13448 --stop 0.15616 --target 0.10837 --side short \
      --leverage 10 --maintenance 0.03 --win-rate 45
"""
import argparse


def main():
    p = argparse.ArgumentParser(description="Reward/risk, expectancy and liquidation.")
    p.add_argument("--entry", type=float, required=True)
    p.add_argument("--stop", type=float, required=True)
    p.add_argument("--target", type=float, required=True)
    p.add_argument("--side", choices=["long", "short"], required=True)
    p.add_argument("--leverage", type=float, default=None)
    p.add_argument("--maintenance", type=float, default=0.005)
    p.add_argument("--win-rate", type=float, default=None, help="percent, e.g. 45")
    a = p.parse_args()

    risk = abs(a.entry - a.stop)
    reward = abs(a.target - a.entry)
    rr = reward / risk
    be = 1.0 / (1.0 + rr) * 100.0

    print("TRADE GEOMETRY")
    print(f"  side              {a.side}")
    print(f"  entry             {a.entry:g}")
    print(f"  stop              {a.stop:g}   ({risk / a.entry * 100:.2f}% away)")
    print(f"  target            {a.target:g}   ({reward / a.entry * 100:.2f}% away)")
    print(f"  R multiple        {rr:.2f}R")
    print(f"  break-even win rate  {be:.1f}%")
    if rr < 2:
        print("  WARNING: below the 2R minimum — factor 6 fails.")

    if a.win_rate is not None:
        w = a.win_rate / 100.0
        ev = w * rr - (1 - w) * 1.0
        print(f"  expectancy at {a.win_rate:g}% win rate:  {ev:+.2f}R per trade")
        print(f"  over 30 trades:                {ev * 30:+.1f}R")

    if a.leverage:
        liq_dist = 1.0 / a.leverage - a.maintenance
        liq = a.entry * (1 - liq_dist) if a.side == "long" else a.entry * (1 + liq_dist)
        reachable = (a.stop > liq) if a.side == "long" else (a.stop < liq)
        print("LIQUIDATION")
        print(f"  at {a.leverage:g}x, maintenance {a.maintenance * 100:.2f}%")
        print(f"  liquidation distance  {liq_dist * 100:.2f}%  ->  price {liq:.6g}")
        print(f"  stop reachable?       {'YES' if reachable else 'NO — liquidation comes first'}")
        if not reachable:
            max_lev = 1.0 / (risk / a.entry + a.maintenance)
            print(f"  maximum leverage with this stop: {max_lev:.1f}x — use a third of it")
        # barrier sanity check, driftless walk
        up = liq_dist
        down = reward / a.entry
        if a.side == "short":
            p_die = down / (up + down)
            print(f"  P(liquidation before target), driftless: {p_die * 100:.0f}%")


if __name__ == "__main__":
    main()
