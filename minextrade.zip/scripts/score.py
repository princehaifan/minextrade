#!/usr/bin/env python3
"""Turn eight yes/no answers into a verdict.

Usage
-----
score.py 1 1 1 1 1 1 1 0
score.py --json '{"structure":1,"bos":1,"block":1,"fvg":1,"sweep":0,"pool":1,"session":1,"size":1}'
"""
import argparse
import json
import sys

FACTORS = [
    ("structure", "D1/H4 structure unambiguous"),
    ("bos", "clean BOS by candle close"),
    ("block", "fresh order block"),
    ("fvg", "imbalance or FVG on the leg"),
    ("sweep", "liquidity swept before the move"),
    ("pool", "opposing pool at least 2R away"),
    ("session", "right session, no news inside 30 min"),
    ("size", "size fits the plan"),
]


def verdict(flags):
    score = sum(1 for f in flags if f)
    missing = [f"{i + 1}. {label}" for i, (f, (_, label)) in enumerate(zip(flags, FACTORS)) if not f]
    print(f"SCORE {score}/8 — {'PROCEED' if score >= 7 else 'NO TRADE'}")
    if missing:
        print("Missing: " + "; ".join(missing))
    else:
        print("Missing: none")
    if score < 7:
        print("Do not resize, rescale or downgrade this into a different trade.")
    return score


def main():
    p = argparse.ArgumentParser(description="Eight-factor scorecard.")
    p.add_argument("flags", nargs="*", type=int, help="eight values, 1 or 0")
    p.add_argument("--json", type=str, default=None, help="object with the eight factor keys")
    a = p.parse_args()

    if a.json:
        data = json.loads(a.json)
        flags = [1 if data.get(k) else 0 for k, _ in FACTORS]
    elif len(a.flags) == 8:
        flags = [1 if v else 0 for v in a.flags]
    else:
        print("Provide eight 0/1 values or --json with the factor keys.", file=sys.stderr)
        print("Keys: " + ", ".join(k for k, _ in FACTORS), file=sys.stderr)
        raise SystemExit(2)

    verdict(flags)


if __name__ == "__main__":
    main()
