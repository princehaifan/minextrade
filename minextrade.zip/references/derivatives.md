# Leverage, liquidation and perpetuals

## Leverage does not change risk — position size does

A $1,000 position at 10x and the same $1,000 position at 1x lose the same money for the same price move. Leverage only decides how much margin is locked and **where the position is liquidated**. Two traders with identical notional and different leverage have identical P&L and completely different survival.

State this explicitly whenever a user says "10x means 10x the profit".

## Liquidation distance

For isolated margin:

```
liquidation distance ≈ 1/leverage − maintenance_margin
```

| Leverage | Maintenance 0.5% | Maintenance 3% |
|---|---|---|
| 3x | 32.8% | 30.3% |
| 5x | 19.5% | 17.0% |
| 10x | 9.5% | 7.0% |
| 20x | 4.5% | 2.0% |
| 50x | 1.5% | — |

Small-cap perps carry high maintenance rates — Gate lists CROSS/USDT at **3%**, so 10x liquidates on a 7% move, not a 10% move. Always pull the contract's `maintenance_rate` rather than assuming 0.5%.

## Maximum leverage for a given stop

```
leverage_max = 1 / (stop_distance_% + maintenance_margin)
```

A trade with a 16% structural stop and 3% maintenance cannot use more than `1/(0.16+0.03) ≈ 5.3x` **even if the stop is exactly at the liquidation price** — and it should not, because a liquidation at the stop is not a stop. Use a third of that: 1.5–2x.

If `stop_distance_% > 1/leverage − maintenance_margin`, the stop **cannot execute**. The position dies first. That is an invalid trade at that leverage, not a risky one.

## The other costs

- **Funding.** Paid every 1–8 hours on perps. Small per interval, material on a 10x position held for days. Quote the rate and the interval.
- **Spread and slippage.** Thin books widen exactly when you need to exit. A $750k/day perp is thin; a 50%-of-capital notional is a large fraction of it.
- **Liquidation cascades.** Forced closes hit the book and can fill beyond the bankruptcy price on isolated margin; on cross margin they can take the whole account.
- **ADL and delisting risk.** Auto-deleveraging and delisting notices are real on small caps.
- **Exchange risk.** Custody, withdrawal limits, jurisdiction. A demo contest removes none of it if the trader later funds live.

## Case study — SHORT CROSS/USDT, 10x

The signal: short at market, TP 0.10837, SL 0.15616, "use 5% of capital", 10x.

| Item | Value |
|---|---|
| Price when audited | 0.13448 |
| Implied entry from the brackets | 0.13226 (TP and SL are ±18.06% — symmetric, so generated) |
| Reward to TP | 19.4% |
| Risk to stated SL | 16.1% |
| Liquidation at 10x, 3% maintenance | +7.0% → 0.1439 |
| Gap between liquidation and stop | 9.1% — no stop can execute there |
| R:R at market | 1.2 : 1 |
| Notional at "5% of capital", 10x | 50% of the account |
| Loss on liquidation | 5% of capital — 5× the 1% rule, breaches a −3% daily stop alone |

Verdict: invalid at 10x, oversized at 5%, and under 2R even if the direction is right. The compliant version: enter on a retest after a sweep of the 24h high, stop above it, target the range low, size to 1%, and use leverage low enough that the stop is reachable — `1/(0.04+0.03) ≈ 14x` maximum, so 2–3x in practice.

## Checklist before any leveraged card

1. Notional, not margin, is what you size.
2. Liquidation distance computed from the contract's maintenance rate.
3. Structural stop strictly inside that distance.
4. Leverage quoted as "the maximum at which this stop is reachable", then halved.
5. Funding rate and next apply time stated.
6. Book depth sanity-checked against the notional.
