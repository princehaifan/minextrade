# Journal and review

Log in R, not in currency. R survives a change of account size, instrument and leverage; naira does not.

## Columns

| Field | Notes |
|---|---|
| date, time WAT | Exact entry time, so session patterns become visible |
| instrument, direction | One instrument per row |
| score /8 | With the missing factors named, e.g. "6 — no sweep, target 1.4R" |
| entry, stop, target | The numbers on the card, not the numbers after the fact |
| planned R | Target distance ÷ stop distance |
| risk % | From the sizer |
| result R | Exit price vs entry, divided by the original stop distance |
| rule broken Y/N | The single most valuable column |
| note | One sentence: what would have made this better |

Template: `templates/journal.csv`.

## Metrics that matter

- **Expectancy** = average R per trade. Positive after thirty trades is the only evidence of an edge.
- **Win rate** — meaningless alone; pair it with the average win and average loss.
- **Profit factor** = gross wins ÷ gross losses. Below 1.2 is fragile.
- **Rule-break rate** — the percentage of trades that broke a written rule. Above 10% and the results describe a different strategy than the one being tested.
- **Score correlation** — average result of 7–8 scores versus 6 and below.

## Review cadence

- **After every session (10 minutes).** Screenshot each trade with entry and exit marked. Score it. Write one sentence.
- **Every seven days.** Count rule violations, not profit. If a rule was broken, the week failed regardless of the P&L.
- **After thirty trades.** Compare the 8s, the 7s and the 6s. Most traders discover their 6/8 trades produced all of their losses; that is the finding that changes behaviour.

## The habit worth keeping

Each evening, write down the number of trades you **wanted** to take and the number you **did** take. In the first week the gap is usually large. By the second week it closes — and that closing gap is what discipline looks like on paper. It is also the best available predictor of whether the account still exists in six months.
