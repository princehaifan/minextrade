# Sizing, risk and expectancy

## The formula

```
risk_money = equity × risk_pct
units      = risk_money ÷ |entry − stop|
lots       = units ÷ contract_size          → round DOWN to the broker step
actual_risk = lots × contract_size × |entry − stop|
```

If the rounded lot is below the broker minimum, the trade is too large for the account. **No trade** — never round up.

## Contract sizes to use

| Instrument | contract_size | Note |
|---|---|---|
| FX majors (EURUSD, GBPUSD) | 100,000 units | 1 pip = $10 per standard lot |
| USDJPY | 100,000 units | Pip value ≈ $6.7 at 150; compute, do not assume |
| XAUUSD | 100 oz | $1 move = $100 per lot |
| US100 / US30 (CFD) | 1 unit | $1 per point per lot |
| Crypto spot | 1 coin | Exchange-specific |
| Gate / MEXC perps | quanto multiplier | CROSS on Gate = 10 coins per contract; pass `--lot-step 1 --min-lot 1` because contracts are whole numbers |

## Worked examples — $10,000 account, 1% = $100

| Trade | Entry | Stop | Distance | Units | Lots | Actual risk |
|---|---|---|---|---|---|---|
| EURUSD long | 1.0824 | 1.0789 | 35 pips | 28,571 | 0.28 | $98 |
| XAUUSD long | 4,120 | 4,105 | $15 | 6.67 oz | 0.06 | $90 |
| US100 long | 24,850 | 24,720 | 130 pts | 0.77 | 0.76 | $99 |
| CROSS perp short | 0.13448 | 0.14850 | 0.01402 | 7,132 coins | 713 contracts | $100 |

The lot size is an output. Never an input.

## The risk ladder

| Phase | Risk per trade | Objective | Rules |
|---|---|---|---|
| Opening — first 40% of the clock | 1–2% | Be positive, stay alive, collect data | Only 7+/8. Max two trades a day. No trade in the first hour |
| Middle — next 40% | 2–5% | Build a buffer, then press | Escalate only after two consecutive winners; back to 2% after any loss; never above 5% while below starting balance |
| Endgame — final 20% | 5–10% | Convert position into a prize | One escalated trade maximum. Win: stop for the day. Lose: done escalating |

## Why drawdown is asymmetric

| Drawdown | Gain needed to recover |
|---|---|
| 5% | 5.3% |
| 10% | 11.1% |
| 15% | 17.6% |
| 20% | 25.0% |
| 25% | 33.3% |
| 30% | 42.9% |
| 50% | 100% |
| 75% | 300% |

This is why a 25% drawdown is a disqualification rather than an inconvenience: you would need +33% just to get back to where you started, with less time and less capital.

## Hard rules

Max 3 trades a day · max 2 open · no correlated positions · no entries ±30 min around high-impact news · no averaging down · no martingale or grid · journal every trade before the next one · stop after 2 losses in a day · stop after −6% in a week.

## Expectancy — the only number that matters

```
E = (win rate × average win in R) − (loss rate × average loss in R)
```

At 45% and 2R: `(0.45 × 2) − (0.55 × 1) = +0.35R` per trade. Over 30 trades, +10.5R.

| Average winner | Break-even win rate |
|---|---|
| 1R | 50.0% |
| 1.5R | 40.0% |
| 2R | 33.3% |
| 3R | 25.0% |

A 90% win rate requires an average winner of about 0.11R — risking 9 to make 1. One loss erases nine wins, and three in a row ends a contest with a 25% drawdown rule. When a user asks for a high win rate, show them this table instead of agreeing.

## Contest arithmetic

Percentage-gain contests are won in the tail, not the median. Simulation of 30 trades at 45% win rate and 2R: at 1% risk, the chance of doubling is roughly nil and the chance of a 25% drawdown is nil; at 5%, about 23% double and 13% are disqualified; at 10%, roughly half double and two in five are disqualified; at 20%, the upside tail explodes and two out of three runs die. State these numbers when a user wants to "go big" in the last week — the choice is between a 50% chance of a prize and a 66% chance of nothing.
