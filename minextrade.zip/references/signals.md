# Auditing a signal

Users paste signals constantly — a screenshot, a Telegram forward, a friend's "sure thing". Audit, do not admire. The output is a verdict, not encouragement.

## The seven-step audit

1. **Is there an entry price?** "Market" is not an entry. If the message gives only TP and SL, derive the implied entry from the bracket and state it, then compare with the live price. The R:R you are actually getting is the one at the current price, not the one in the message.
2. **Are the brackets symmetric?** Divide TP and SL by the implied entry. If the two percentages are identical (±18.06% and ±18.07%, for example), the levels came from a generator, not from a chart. Say so.
3. **What is the R multiple at market?** `(entry − TP)/(SL − entry)` for a short, the reverse for a long. Under 2R fails factor 6 before anything else is considered.
4. **Where is liquidation?** `1/leverage − maintenance_margin`. If the stop is beyond that distance, the stop cannot execute. This is the most common fatal flaw in leveraged signals and the one users never check.
5. **What does the stated size actually mean?** "Use 5% of capital" at 10x is 50% notional. Convert it to a loss at the stop and at liquidation, in money and in % of equity, and compare with the 1% rule.
6. **What is the probability of the stop/liquidation being hit before the target?** For a driftless walk between two barriers, `P(upper first) = D/(U+D)`. Use it as a sanity check, not a forecast, and say so.
7. **Is there any structural claim at all?** Structure, BOS, order block, FVG, sweep, pool. If none are named, the scorecard score is 0/8 and the signal is a bracket, not an analysis.

## Red flags

No entry price · symmetric brackets · "use X% of capital" without a stop distance · leverage above 10x · "100% accuracy", "never lost", "guaranteed" · screenshots without timestamps · no invalidation level · invitation to a paid group · a TP below today's low or an SL above today's high with no explanation of why the range should break.

## Verdict format

```
VERDICT — not tradeable as sent
Price now 0.13448 | implied entry 0.13226 | R:R 1.2:1
Liquidation at 10x = +7.0% (0.1439) — stop at 0.15616 is 9.1% beyond it
Size "5% at 10x" = 50% notional = −5% of capital on liquidation (5× the 1% rule)
Scorecard 0/8: no structure, BOS, block, gap, sweep; target < 2R; size fails
Compliant version: entry 0.1420–0.1450 after a sweep of the 24h high, stop 0.1485,
target 0.1195 (≈4R), 1% risk, ≤2x leverage
```

## Tone

Deliver the verdict in the first line, then the arithmetic that supports it, then the compliant alternative if one exists. Never soften a fatal flaw into a "consideration". Never repeat a signal as a recommendation, and never tell the user what to do with money already committed beyond the rule that applies.

## When the user is already in the position

Work from the live price, not the entry. Compute the remaining risk to the stop and to liquidation, then answer one question: is there an exit condition in `references/execution.md`? If yes, CLOSE or REDUCE. If no, HOLD with the level that would change the answer. Do not average down to "improve" the entry, ever.
