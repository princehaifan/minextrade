# The eight-factor scorecard

One point per factor. **7–8 proceed. 6 or fewer: no trade.** A missing factor is a zero, not a discussion.

| # | Question | Passes when | Fails when | Evidence to demand |
|---|---|---|---|---|
| 1 | Is the D1/H4 structure unambiguous? | Two or more clean higher highs **and** higher lows (or lower highs and lower lows) | A range, or a bias you have to argue for | The last three swings marked on D1 or H4 |
| 2 | Has there been a clean BOS in that direction? | A **candle close** beyond the most recent swing, on the execution timeframe | A wick through the level that closes back inside | The candle, its close, and the swing it broke |
| 3 | Is there a fresh order block? | Last opposing candle before the break, untested or tested once | A block already tapped twice, or one from another leg | The block's high and low, and the count of retests |
| 4 | Is there an imbalance or FVG inside that leg? | Three-candle gap on the displacement that broke structure, sitting on the block | A gap from a different leg, or one already filled | Candle 1 high and candle 3 low, plus the fill status |
| 5 | Was liquidity swept before the move? | Wick through an obvious pool (Asian high/low, equal highs, PDH/PDL) that closes back inside, then displacement | Entry on the **break** of the pool instead of the reclaim | The pool, the wick, the close |
| 6 | Is there an opposing pool at least 2R away? | PDH/PDL, equal highs, session extreme at ≥2× the stop distance | A round number, a moving average, or "the next resistance" | The pool and the arithmetic to it |
| 7 | Is the session right, with no news inside 30 minutes? | London 08:00–11:00 or New York 14:00–17:00 WAT, calendar clear | 22:00 on a Friday, or five minutes before a release | Clock in WAT and the calendar entry |
| 8 | Does the size fit the plan? | Stop inside budget, risk within the phase cap, no correlation with open trades | "5% of capital", two correlated longs, or a size chosen before the stop | The position_size.py output |

Crypto trades on a 24/7 market: factor 7 becomes liquidity and calendar, not session — thin books at 03:00 WAT and funding timestamps still count. Everything else is unchanged.

## Scoring in sixty seconds

1. Mark the last three swings on D1/H4. If you cannot, stop: factor 1 is zero and the trade is dead.
2. Drop to the execution timeframe and find the most recent displacement that closed beyond a swing — that is the leg you are allowed to trade.
3. Inside that leg, mark the order block and the gap. If they are not both there, factors 3 and 4 fail.
4. Look left of the leg for the pool that was swept. If price broke the pool instead of reclaiming it, factor 5 fails.
5. Mark the next pool in your direction. Divide by the stop distance. Under 2R, factor 6 fails.
6. Check the clock and the calendar.
7. Run the sizer.

## Worked example — EURUSD, 8/8

Asian range 1.0800–1.0830. At 08:55 price wicks to 1.0791 and closes 1.0812 (factor 5). Displacement closes 1.0838 through the 1.0830 swing (factor 2), leaving an order block at 1.0801–1.0814 (factor 3) and an FVG at 1.0821–1.0829 (factor 4). H4 has printed higher highs and higher lows since Tuesday (factor 1). Entry 1.0824 on the retrace, stop 1.0789 below the sweep (35 pips), target 1.0902 at the prior day's high (78 pips, 2.2R — factor 6). London, 09:15, nothing on the calendar until 13:30 (factor 7). $10,000 account, 1% = $100, 35 pips → 0.28 lots → $98 risk (factor 8).

Score 8/8. The trade is allowed.

## The counter-example — the same chart at 6/8

Enter on the break of 1.0830 instead of the reclaim: factor 5 fails, and the stop now sits mid-range where the next sweep collects it. Take 1.2R at the round number because the prior day's high "looks far": factor 6 fails. Same direction, same confidence, 6/8 — and the plan does not allow it.

A skipped 6/8 that would have won is not evidence the filter is wrong. It is the filter working.

## Do not score up

If you find yourself arguing that a 5 is really a 7 — "the daily looks bullish", "the news was probably priced in" — the argument is already lost. The scorecard works while it is arithmetic. The moment it becomes a discussion it is decoration.

## What the score is for

Log the score with every trade. After thirty trades, compare the average result of the 7s and 8s against the 6s. Most traders find their 6/8 trades produced all of their losses. That comparison, not the win rate, is what tells you whether the process has an edge.
