# Order card

```
SCORE x/8 — PROCEED | NO TRADE
Missing: none | 3. fresh order block, 6. pool under 2R

Instrument:      EURUSD          Timeframe: M5        Session: London 09:15 WAT
Bias:            H4 higher highs and higher lows since Tuesday
Zone:            order block 1.0801–1.0814, FVG 1.0821–1.0829
Trigger:         model B — M5 close back above 1.0821

Entry:           1.0824
Stop:            1.0789   (35 pips, 0.32%)   beyond the sweep low 1.0791 + buffer
Target:          1.0902   (78 pips, 2.2R)    prior day high
Management:      50% at 2R (1.0894), 30% at 1.0902, 20% trailing behind the last M5 swing

Size:            0.28 lots = $98 risk = 0.98% of $10,000
Liquidation:     n/a (spot FX)

Rule check:      trades today 1/3 | open 0/2 | correlation none | news clear until 13:30
Invalidation:    M5 close back through 1.0814 with displacement down
Time stop:       12 M5 candles without 0.5R of progress
```

## Rules for filling it in

- Score first, size second, card third. Never the other way round.
- The stop is a chart level, not a number that makes the size look nice.
- If the card cannot be completed — no pool, no invalidation, no time stop — the trade is not ready.
- Write the score into the journal before the order goes in, not after the result is known.
