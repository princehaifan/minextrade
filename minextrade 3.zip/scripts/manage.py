#!/usr/bin/env python3
"""Live trade state: R now, the partial ladder, and the risk still open.

Examples
--------
manage.py --side short --entry 71.50 --stop 72.55 --target 69.20 --size 95 --price 69.40
manage.py --side short --entry 71.50 --stop 72.55 --target 69.20 --size 95 \
          --price 69.10 --stop-now 71.50 --equity 10000
"""
import argparse


def main():
    p = argparse.ArgumentParser(description="Partial-profit and open-risk bookkeeping.")
    p.add_argument("--side", choices=["long", "short"], required=True)
    p.add_argument("--entry", type=float, required=True)
    p.add_argument("--stop", type=float, required=True, help="original stop")
    p.add_argument("--target", type=float, required=True)
    p.add_argument("--size", type=float, required=True, help="units or contracts at entry")
    p.add_argument("--price", type=float, default=None, help="current price")
    p.add_argument("--stop-now", type=float, default=None, help="stop after any move to breakeven")
    p.add_argument("--equity", type=float, default=None)
    a = p.parse_args()

    dirn = 1 if a.side == "long" else -1           # profit direction in price terms
    risk_unit = abs(a.entry - a.stop)
    one_r_money = a.size * risk_unit
    r_target = abs(a.target - a.entry) / risk_unit

    def r_at(price):
        return dirn * (price - a.entry) / risk_unit

    print("TRADE STATE")
    print(f"  {a.side} {a.size:g} units at {a.entry:g}")
    print(f"  original stop {a.stop:g}  |  1R = {risk_unit:g} per unit = ${one_r_money:,.2f}")
    print(f"  target {a.target:g}  =  {r_target:.2f}R")

    p2 = a.entry + dirn * 2 * risk_unit            # price at +2R
    print("\nPARTIAL LADDER  (50 / 30 / 20)")
    print(f"  2R at {p2:.6g}: close 50% = {a.size * 0.5:g} units, bank +1.00R "
          f"(${0.5 * 2 * one_r_money:,.2f}), move stop to breakeven")
    print(f"  target {a.target:g}: close 30% = {a.size * 0.3:g} units, "
          f"bank +{0.3 * r_target:.2f}R (${0.3 * r_target * one_r_money:,.2f})")
    print(f"  runner 20% = {a.size * 0.2:g} units, trail behind the last M5 swing")

    banked_at_target = 0.5 * 2 + 0.3 * r_target
    print("\nIF THE LADDER RUNS TO TARGET")
    print(f"  banked +{banked_at_target:.2f}R, runner still open with 20% of the size")
    print(f"  worst case after the 2R partial: +1.00R locked, stop at breakeven")

    if a.price is not None:
        r_now = r_at(a.price)
        print("\nNOW")
        print(f"  price {a.price:g}  ->  {r_now:+.2f}R on the full size "
              f"(${r_now * one_r_money:,.2f})")
        if r_now < 2 - 1e-9:
            print(f"  action: HOLD — 2R is {max(0.0, (2 - r_now)) * risk_unit:.3g} away at {p2:.6g}")
        elif r_now < r_target:
            print("  action: TAKE THE 2R PARTIAL if not already taken; stop to breakeven")
        else:
            print("  action: TAKE THE TARGET TRANCHE; runner trails")

        if a.stop_now is not None:
            if r_now >= r_target - 1e-9:
                remaining = a.size * 0.2
            elif r_now >= 2 - 1e-9:
                remaining = a.size * 0.5
            else:
                remaining = a.size
            signed = -dirn * (a.stop_now - a.entry) * remaining   # + is loss, - is locked profit
            open_risk = max(0.0, signed)
            locked = max(0.0, -signed)
            print("\nOPEN RISK AFTER THE MOVE")
            print(f"  remaining {remaining:g} units, stop now {a.stop_now:g}")
            print(f"  open risk ${open_risk:,.2f}" +
                  (f" = {open_risk / a.equity * 100:.2f}% of equity" if a.equity else ""))
            if locked > 0:
                print(f"  stop is in profit: +${locked:,.2f} locked on the remainder "
                      f"({locked / one_r_money:+.2f}R)")
            if open_risk <= 1e-9:
                print("  risk-free: the stop is at or beyond entry, the trade cannot lose now")


if __name__ == "__main__":
    main()
