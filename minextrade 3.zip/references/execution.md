# Execution, management and exit

A zone is not a trade. The difference is a trigger, a stop where the idea is genuinely wrong, and a target that exists on the chart before entry.

## Three entry models — pick one and keep it for the whole contest

| Model | Trigger | Advantage | Cost |
|---|---|---|---|
| A · Passive limit | Resting order at 50% of the order block, or the near edge of the FVG | Best price, no screen time | Misses trades that never tap the level; no confirmation |
| B · Confirmation close | M5 candle closes back out of the zone in your direction | Price has already reacted | Entry worse by the size of the confirmation candle |
| C · Sweep then CHoCH | Price sweeps the pool, then M5 breaks its last opposing swing | Highest win rate of the three | Fewest opportunities; sometimes you enter after half the move |

Inconsistency kills competition accounts, not a suboptimal entry. A journal full of one setup is data; a journal full of five setups is a diary.

## Where the stop goes

- **Beyond the low that created the setup** — the sweep low or the order block low — plus a buffer of 0.2–0.3 × ATR(14), or 2–5 pips on FX majors.
- **Never inside the zone.** A stop inside the order block is a bet against the level you claim to trust.
- **Never wider than 1.5× your average stop.** If the structural stop is that far, the position is too big or the setup is not there. Skip it; do not widen and hope.
- **Never moved further away.** Moving a stop against you turns a 1R loss into an account-ending one.

## Where the target goes

Targets are liquidity, not round numbers. First target: the nearest opposing pool — PDH/PDL, an equal-high cluster, the Asian range extreme. Second target: the next pool beyond it. **If the first target is closer than 2R, the trade is not worth taking.** Wait for a setup with room.

## Managing the position

**50 / 30 / 20.** Take 50% at 2R, 30% at the second pool, leave 20% with a trailing stop behind the most recent M5 swing. Not the highest-expectancy exit in theory; the one traders actually follow under pressure.

Move the stop to breakeven only after +1R is banked **and** structure still holds. Not before, and never as a substitute for a plan.

## Exit and flatten protocol

Close the whole position the moment any of these is true:

1. **Target.** Final target reached, or the runner's trail is hit.
2. **Invalidation.** M5 closes back through the order block or the sweep level with displacement against you.
3. **Time stop.** Less than 0.5R of progress after 12 M5 candles from entry — the idea is not being paid for.
4. **Session end.** Flatten before the killzone closes. Never carry into the next session.
5. **News.** A high-impact release inside 15 minutes — flatten, or reduce to the runner only.
6. **Daily stop.** 2 losses or −3% on the day — flatten everything and stop for the day.
7. **Weekly breaker.** −6% on the week — flatten and stop for the week.

Never widen a stop, average down, add to a loser, or re-enter the same setup in the same session after being stopped out.

## Answering "should I close?"

Return **CLOSE / HOLD / REDUCE** and the single rule that decides it. Examples:

- "CLOSE — invalidation: M5 closed back through the order block at 1.0814 with displacement against you."
- "REDUCE — 2R printed; take the 50% and trail the rest behind the last M5 swing."
- "HOLD — no exit condition met; the time stop is four candles away."

## Answering "close everything"

Return **FLATTEN ALL**, list each open position with the rule that justifies closing it (session end, daily stop, invalidation, manual instruction), and confirm the account is flat. If a position is in profit and no rule requires closing it, say so before flattening — the trader may be asking out of fear, and that is worth one sentence.

## Language to avoid

"Looks strong", "should hold", "probably", "high probability", "almost there". Replace each with the factor, the level, or the rule that produced the statement.

## Live bookkeeping — partials and open risk

Partial exits are mechanical. The ladder is fixed before entry, so the only decision left during the trade is whether an exit condition has been met.

| Stage | Action | Effect on risk |
|---|---|---|
| +2R | Close 50%, move the stop to breakeven | 1.00R banked, remainder risks nothing |
| Second pool | Close 30% | Banked R rises by 0.3 × the R at that pool |
| Runner (20%) | Trail behind the last M5 swing | Open risk is whatever the trail allows |

Two formulas do all the work:

```
banked_R   = Σ (fraction closed × R at that exit)
open_risk  = max(0, (entry − stop_now) × remaining_size)     # long
open_risk  = max(0, (stop_now − entry) × remaining_size)     # short
```

If the stop has moved beyond entry, open risk is zero and the difference is **locked profit**, not risk. Never count a locked-profit position as risk when sizing the next trade.

Run `scripts/manage.py` at any point in the trade to get the current R, the ladder in units and money, and the open risk on the remainder:

```
manage.py --side short --entry 71.50 --stop 72.55 --target 69.20 --size 95 \
          --price 69.40 --stop-now 71.50 --equity 10000
```

Two rules that follow from the arithmetic:

- **Never re-enter a trade you have partially closed** because "it looks strong again". The ladder already expresses your view; a second entry is a new trade and must pass all eight factors on its own.
- **Never widen the stop to avoid taking a partial.** The partial exists precisely so that the decision is not a negotiation.

## What "dynamic" does not mean

The skill never adds to a winner, never pyramids, never scales into a loser, and never increases size after a loss to "get it back". Escalation happens at the card level — the phase risk percentage — not by stacking entries. A trader with two open positions has two cards, each sized against the remaining risk budget, not one position that grew.
